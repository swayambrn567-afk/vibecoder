import type { Config, Context } from "@netlify/functions"

const SYSTEM = `You are Nexus, an expert front-end engineer. Build exactly what the user asks as ONE complete, self-contained HTML file (inline CSS and JS, no build step, CDN scripts only from cdnjs.cloudflare.com). Make it modern, responsive and polished, with real working interactions. If given existing code, modify it per the request and return the full updated file. Respond with ONLY the raw HTML starting with <!DOCTYPE html>. No markdown fences, no explanation.`

export default async (req: Request, _ctx: Context) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 })

  // Login required: verify the Netlify Identity token
  const auth = req.headers.get("authorization") || ""
  const who = auth ? await fetch(`${new URL(req.url).origin}/.netlify/identity/user`, { headers: { authorization: auth } }) : null
  if (!who || !who.ok) return Response.json({ error: "Please log in first." }, { status: 401 })

  const key = Netlify.env.get("GROQ_API_KEY")
  if (!key) return Response.json({ error: "GROQ_API_KEY is not set on the server." }, { status: 500 })

  const { prompt, current } = await req.json()
  if (!prompt || typeof prompt !== "string") return Response.json({ error: "Prompt missing." }, { status: 400 })

  const user = current
    ? `Current code:\n${String(current).slice(0, 40000)}\n\nChange request: ${prompt}`
    : prompt

  const r = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: "llama-3.3-70b-versatile",
      temperature: 0.4,
      max_tokens: 6000,
      messages: [{ role: "system", content: SYSTEM }, { role: "user", content: user }],
    }),
  })
  if (!r.ok) return Response.json({ error: `AI error (${r.status})` }, { status: 502 })

  const data = await r.json()
  let html: string = data.choices?.[0]?.message?.content ?? ""
  html = html.replace(/^```(?:html)?\s*/i, "").replace(/```\s*$/, "").trim()
  return Response.json({ html })
}

export const config: Config = { path: "/api/generate", method: "POST" }
